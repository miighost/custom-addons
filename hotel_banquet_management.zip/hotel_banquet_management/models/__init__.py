# -*- coding: utf-8 -*-
from . import banquet_event_type
from . import banquet_venue
from . import banquet_order
from . import account_move
from . import banquet_customer_statement
from . import banquet_partner_ledger
from . import res_partner
from . import banquet_flaad_quotation
